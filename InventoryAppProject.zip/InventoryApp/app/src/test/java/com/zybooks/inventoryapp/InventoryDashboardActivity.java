package com.zybooks.inventoryapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class InventoryDashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_dashboard);
        // Make sure you already have res/layout/activity_inventory_dashboard.xml
    }
}

