package com.zybooks.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DbHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "inventory_db.sqlite";
    private static final int DB_VERSION = 1;

    // inventory_items
    public static final String T_ITEMS = "inventory_items";
    public static final String C_ID = "_id";
    public static final String C_SKU = "sku";
    public static final String C_NAME = "name";
    public static final String C_QTY = "qty";
    public static final String C_CREATED = "createdAt";

    // users (not shown in grid)
    public static final String T_USERS = "users";
    public static final String CU_ID = "_id";
    public static final String CU_USERNAME = "username";
    public static final String CU_PASSWORD = "passwordHash";
    public static final String CU_CREATED = "createdAt";

    public DbHelper(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + T_ITEMS + " (" +
                C_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                C_SKU + " TEXT NOT NULL, " +
                C_NAME + " TEXT NOT NULL, " +
                C_QTY + " INTEGER NOT NULL DEFAULT 0, " +
                C_CREATED + " INTEGER NOT NULL" +
                ")");
        db.execSQL("CREATE TABLE " + T_USERS + " (" +
                CU_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                CU_USERNAME + " TEXT UNIQUE NOT NULL, " +
                CU_PASSWORD + " TEXT NOT NULL, " +
                CU_CREATED + " INTEGER NOT NULL" +
                ")");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // simple dev strategy
        db.execSQL("DROP TABLE IF EXISTS " + T_ITEMS);
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        onCreate(db);
    }

    // ---------- CRUD for items ----------
    public long addItem(String sku, String name, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(C_SKU, sku);
        cv.put(C_NAME, name);
        cv.put(C_QTY, qty);
        cv.put(C_CREATED, System.currentTimeMillis());
        return db.insert(T_ITEMS, null, cv);
    }

    public int updateItem(long id, String sku, String name, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(C_SKU, sku);
        cv.put(C_NAME, name);
        cv.put(C_QTY, qty);
        return db.update(T_ITEMS, cv, C_ID + "=?", new String[]{ String.valueOf(id) });
    }

    public int deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(T_ITEMS, C_ID + "=?", new String[]{ String.valueOf(id) });
    }

    public List<InventoryItem> getAllItems() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(T_ITEMS, null, null, null, null, null, C_NAME + " ASC");
        List<InventoryItem> list = new ArrayList<>();
        try {
            int idxId = c.getColumnIndexOrThrow(C_ID);
            int idxSku = c.getColumnIndexOrThrow(C_SKU);
            int idxName = c.getColumnIndexOrThrow(C_NAME);
            int idxQty = c.getColumnIndexOrThrow(C_QTY);
            int idxCreated = c.getColumnIndexOrThrow(C_CREATED);
            while (c.moveToNext()) {
                InventoryItem it = new InventoryItem(
                        c.getLong(idxId),
                        c.getString(idxSku),
                        c.getString(idxName),
                        c.getInt(idxQty),
                        c.getLong(idxCreated)
                );
                list.add(it);
            }
        } finally { c.close(); }
        return list;
    }

    // ---------- (Optional) simple user storage ----------
    public long addUser(String username, String passwordHash) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(CU_USERNAME, username);
        cv.put(CU_PASSWORD, passwordHash);
        cv.put(CU_CREATED, System.currentTimeMillis());
        return db.insert(T_USERS, null, cv);
    }
    // ---------- USERS: login & register ----------

    /** Register a new user. Returns true if created, false if username exists or insert failed. */
    public boolean registerUser(String username, String password, boolean useHash) {
        String toStore = useHash ? sha256(password) : password;

        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(CU_USERNAME, username);
        cv.put(CU_PASSWORD, toStore);
        cv.put(CU_CREATED, System.currentTimeMillis());
        long rowId = -1;
        try {
            rowId = db.insert(T_USERS, null, cv);
        } catch (android.database.sqlite.SQLiteConstraintException ignore) {
            // username UNIQUE constraint hit
        }
        return rowId != -1;
    }

    /** Check credentials. Returns true on match. */
    public boolean checkLogin(String username, String password, boolean useHash) {
        String toCheck = useHash ? sha256(password) : password;

        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(
                T_USERS,
                new String[]{ CU_ID },
                CU_USERNAME + "=? AND " + CU_PASSWORD + "=?",
                new String[]{ username, toCheck },
                null, null, null
        );
        boolean ok = false;
        try {
            ok = c.moveToFirst();
        } finally {
            c.close();
        }
        return ok;
    }

    /** Optional helper if you ever need to know if a username exists. */
    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(T_USERS, new String[]{CU_ID}, CU_USERNAME + "=?",
                new String[]{ username }, null, null, null);
        boolean exists = false;
        try { exists = c.moveToFirst(); } finally { c.close(); }
        return exists;
    }

    /** Simple SHA-256 (demo-grade). */
    private static String sha256(String input) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(input.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(bytes.length * 2);
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            // Fallback to plain if hashing somehow fails (shouldn't)
            return input;
        }
    }
}
