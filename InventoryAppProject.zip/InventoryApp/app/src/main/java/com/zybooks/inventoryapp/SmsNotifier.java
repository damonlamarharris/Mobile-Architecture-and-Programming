package com.zybooks.inventoryapp;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

/** Tiny helper that only sends an SMS if permission is granted. */
public final class SmsNotifier {

    private SmsNotifier() {}

    /** @return true if an SMS was actually sent (permission + nonempty phone). */
    public static boolean trySend(Context context, String phone, String message) {
        if (phone == null || phone.trim().isEmpty()) return false;

        boolean granted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;

        if (!granted) return false;

        SmsManager smsManager;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            smsManager = context.getSystemService(SmsManager.class);
        } else {
            smsManager = SmsManager.getDefault();
        }

        smsManager.sendTextMessage(phone, null, message, null, null);
        return true;
    }
}

