package com.zybooks.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Reusable runtime-permission helper for SEND_SMS.
 *
 * Usage:
 *   SmsPermissionDelegate perms = new SmsPermissionDelegate(this, granted -> { ... });
 *   perms.request(); // prompts if needed; callback receives the result
 */
public class SmsPermissionDelegate {

    public interface Callback { void onResult(boolean granted); }

    private final ComponentActivity activity;
    private final Callback callback;
    private final ActivityResultLauncher<String> launcher;

    public SmsPermissionDelegate(ComponentActivity activity, Callback callback) {
        this.activity = activity;
        this.callback = callback;
        this.launcher = activity.registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                granted -> {
                    callback.onResult(granted);
                    if (!granted && isPermanentlyDenied()) {
                        showSettingsDialog();
                    }
                }
        );
    }

    public boolean hasPermission() {
        return ContextCompat.checkSelfPermission(
                activity, Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    /** Request permission (shows rationale if appropriate). */
    public void request() {
        if (hasPermission()) {
            callback.onResult(true);
            return;
        }
        if (ActivityCompat.shouldShowRequestPermissionRationale(
                activity, Manifest.permission.SEND_SMS)) {
            new AlertDialog.Builder(activity)
                    .setTitle("Allow SMS alerts?")
                    .setMessage("To send low-stock alerts as text messages, we need SMS permission. " +
                            "You can still use the app without SMS.")
                    .setPositiveButton("Continue", (d, w) -> launcher.launch(Manifest.permission.SEND_SMS))
                    .setNegativeButton("Not now", (d, w) -> callback.onResult(false))
                    .show();
        } else {
            launcher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private boolean isPermanentlyDenied() {
        return !ActivityCompat.shouldShowRequestPermissionRationale(
                activity, Manifest.permission.SEND_SMS)
                && !hasPermission();
    }

    private void showSettingsDialog() {
        new AlertDialog.Builder(activity)
                .setTitle("Enable SMS in Settings")
                .setMessage("You chose not to allow SMS. If you change your mind, enable the permission in App Settings.")
                .setPositiveButton("Open Settings", (d, w) -> {
                    Intent intent = new Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + activity.getPackageName())
                    );
                    activity.startActivity(intent);
                })
                .setNegativeButton("Close", null)
                .show();
    }
}

