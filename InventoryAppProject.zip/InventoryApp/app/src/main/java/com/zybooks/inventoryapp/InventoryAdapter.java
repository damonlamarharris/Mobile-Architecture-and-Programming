package com.zybooks.inventoryapp;
import com.zybooks.inventoryapp.R;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.VH> {

    public interface Listener {
        void onClick(InventoryItem item);
        void onLongClick(InventoryItem item);
    }

    private final Listener listener;
    private final List<InventoryItem> data = new ArrayList<>();

    public InventoryAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submitList(List<InventoryItem> items) {
        data.clear();
        if (items != null) data.addAll(items);
        notifyDataSetChanged();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvName, tvSku, tvQty;
        VH(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvSku  = itemView.findViewById(R.id.tvSku);
            tvQty  = itemView.findViewById(R.id.tvQty);
        }
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.inventory_item_row, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        InventoryItem item = data.get(position);
        h.tvName.setText(item.name);
        h.tvSku.setText("SKU: " + item.sku);
        h.tvQty.setText("Qty: " + item.qty);
        h.itemView.setOnClickListener(v -> listener.onClick(item));
        h.itemView.setOnLongClickListener(v -> { listener.onLongClick(item); return true; });
    }

    @Override public int getItemCount() { return data.size(); }

    public InventoryItem getItem(int pos) { return data.get(pos); }
}

