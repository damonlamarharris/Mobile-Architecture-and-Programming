package com.zybooks.inventoryapp;

public class InventoryItem {
    public long id;
    public String sku;
    public String name;
    public int qty;
    public long createdAt;

    public InventoryItem(long id, String sku, String name, int qty, long createdAt) {
        this.id = id;
        this.sku = sku;
        this.name = name;
        this.qty = qty;
        this.createdAt = createdAt;
    }
}

