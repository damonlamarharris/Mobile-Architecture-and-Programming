package com.zybooks.inventoryapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DbHelper db;
    private InventoryAdapter adapter;
    private RecyclerView rv;
    private FloatingActionButton fab;
    private MaterialToolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_dashboard);

        db = new DbHelper(this);

        toolbar = findViewById(R.id.topAppBar);
        setSupportActionBar(toolbar);
        toolbar.setOnMenuItemClickListener(this::onMenuItemClick);

        rv = findViewById(R.id.rvItems);
        rv.setLayoutManager(new GridLayoutManager(this, 2));

        adapter = new InventoryAdapter(new InventoryAdapter.Listener() {
            @Override public void onClick(InventoryItem item) { showEditDialog(item); }
            @Override public void onLongClick(InventoryItem item) { confirmDelete(item); }
        });
        rv.setAdapter(adapter);

        // swipe to delete
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override public boolean onMove(@NonNull RecyclerView rv, @NonNull RecyclerView.ViewHolder v, @NonNull RecyclerView.ViewHolder t) { return false; }
            @Override public void onSwiped(@NonNull RecyclerView.ViewHolder vh, int dir) {
                InventoryItem item = adapter.getItem(vh.getBindingAdapterPosition());
                db.deleteItem(item.id);
                reload();
                Snackbar.make(rv, "Deleted " + item.name, Snackbar.LENGTH_LONG)
                        .setAction("Undo", v -> { db.addItem(item.sku, item.name, item.qty); reload(); })
                        .show();
            }
        }).attachToRecyclerView(rv);

        fab = findViewById(R.id.fabAdd);
        fab.setOnClickListener(v -> showAddDialog());

        reload(); // initial READ
    }

    private boolean onMenuItemClick(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            finish();
            return true;
        }
        return false;
    }

    private void reload() {
        List<InventoryItem> items = db.getAllItems(); // READ
        adapter.submitList(items);
    }

    private void showAddDialog() {
        LayoutInflater inf = LayoutInflater.from(this);
        final android.view.View view = inf.inflate(R.layout.dialog_inventory_item, null, false);
        final EditText etName = view.findViewById(R.id.etName);
        final EditText etSku  = view.findViewById(R.id.etSku);
        final EditText etQty  = view.findViewById(R.id.etQty);

        new AlertDialog.Builder(this)
                .setTitle("Add Item")
                .setView(view)
                .setPositiveButton("Save", (d, w) -> {
                    String name = etName.getText().toString().trim();
                    String sku  = etSku.getText().toString().trim();
                    int qty = safeInt(etQty.getText().toString());
                    db.addItem(sku, name, qty);   // CREATE
                    reload();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showEditDialog(final InventoryItem original) {
        LayoutInflater inf = LayoutInflater.from(this);
        final android.view.View view = inf.inflate(R.layout.dialog_inventory_item, null, false);
        final EditText etName = view.findViewById(R.id.etName);
        final EditText etSku  = view.findViewById(R.id.etSku);
        final EditText etQty  = view.findViewById(R.id.etQty);

        etName.setText(original.name);
        etSku.setText(original.sku);
        etQty.setText(String.valueOf(original.qty));

        new AlertDialog.Builder(this)
                .setTitle("Edit Item")
                .setView(view)
                .setPositiveButton("Save", (d, w) -> {
                    String name = etName.getText().toString().trim();
                    String sku  = etSku.getText().toString().trim();
                    int qty = safeInt(etQty.getText().toString());
                    db.updateItem(original.id, sku, name, qty); // UPDATE
                    reload();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void confirmDelete(final InventoryItem item) {
        Snackbar.make(rv, "Delete " + item.name + "?", Snackbar.LENGTH_LONG)
                .setAction("Delete", v -> { db.deleteItem(item.id); reload(); })
                .show();
    }

    private int safeInt(String s) {
        try { return Integer.parseInt(s); } catch (Exception e) { return 0; }
    }
}

