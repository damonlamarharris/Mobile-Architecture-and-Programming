package com.zybooks.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private TextView tvError;
    private Button btnLogin, btnCreate;
    private DbHelper db;
    private final boolean useHash = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new DbHelper(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        tvError    = findViewById(R.id.tvError);
        btnLogin   = findViewById(R.id.btnLogin);
        btnCreate  = findViewById(R.id.btnCreate);

        btnLogin.setOnClickListener(v -> {
            hideError();
            String u = etUsername.getText().toString().trim();
            String p = etPassword.getText().toString();
            if (u.isEmpty() || p.isEmpty()) { showError("Enter username and password"); return; }
            if (db.checkLogin(u, p, useHash)) { Toast.makeText(this,"Welcome, "+u+"!",Toast.LENGTH_SHORT).show(); goToDashboard(); }
            else { showError("Invalid username or password"); }
        });

        btnCreate.setOnClickListener(v -> {
            hideError();
            String u = etUsername.getText().toString().trim();
            String p = etPassword.getText().toString();
            if (u.isEmpty() || p.length() < 4) { showError("Use a username and 4+ char password"); return; }
            if (db.registerUser(u, p, useHash)) { Toast.makeText(this,"Account created. You’re in, "+u+"!",Toast.LENGTH_SHORT).show(); goToDashboard(); }
            else { showError("Username already exists"); }
        });
    }

    private void hideError() { tvError.setVisibility(View.GONE); }
    private void showError(String msg) { tvError.setText(msg); tvError.setVisibility(View.VISIBLE); }
    private void goToDashboard() { startActivity(new Intent(this, MainActivity.class)); finish(); }
}
